# Audit summary

Summary for [Azure DevOps instance](https://dev.azure.com/dpdeepankar/Devops-Project/_build)

- GitHub Actions Importer version: **1.3.22543 (64a9c1ce2299531079ffe72e0b7fb0da525c577d)**
- Performed at: **12/11/25 at 23:20**

## Pipelines

Total: **3**

- Successful: **0 (0%)**
- Partially successful: **3 (100%)**
- Unsupported: **0 (0%)**
- Failed: **0 (0%)**

### Job types

Supported: **3 (100%)**

- YAML: **3**

### Build steps

Total: **30**

Known: **13 (43%)**

- download_artifact: **6**
- Bash@3: **3**
- publish_artifact: **2**
- PublishPipelineArtifact@1: **1**
- checkout: **1**

Unknown: **17 (56%)**

- TerraformTask@5: **8**
- TerraformInstaller@1: **5**
- ManualValidation@1: **2**
- TerraformOutput@1: **2**

Actions: **23**

- actions/checkout@v4.1.0: **8**
- dawidd6/action-download-artifact@v3.0.0: **4**
- run: **3**
- actions/upload-artifact@v4.1.0: **3**
- actions/download-artifact@v4.1.0: **2**
- ./.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_validate_build.yml: **1**
- ./.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_plan_apply.yml: **1**
- ./.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_destroy.yml: **1**

### Triggers

Total: **3**

Known: **3 (100%)**

- pipelines: **2**
- continuousIntegration: **1**

Actions: **4**

- workflow_run: **2**
- push: **1**
- workflow_dispatch: **1**

### Environment

Total: **0**

### Other

Total: **0**

### Partially successful

#### Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline

- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/.github/workflows/terraform-destroy-pipeline.yml](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/.github/workflows/terraform-destroy-pipeline.yml)
- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_destroy.yml](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_destroy.yml)
- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/config.json](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/config.json)
- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/source.yml](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-Destroy-pipeline/source.yml)

#### Devops-Project/Terraform-build-and-deploy/terraform-deploy

- [pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/.github/workflows/terraform-deploy.yml](pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/.github/workflows/terraform-deploy.yml)
- [pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_plan_apply.yml](pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_plan_apply.yml)
- [pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/config.json](pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/config.json)
- [pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/source.yml](pipelines/Devops-Project/Terraform-build-and-deploy/terraform-deploy/source.yml)

#### Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline

- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/.github/workflows/terraform-build-pipeline.yml](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/.github/workflows/terraform-build-pipeline.yml)
- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_validate_build.yml](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/.github/workflows/terraform_build_and_deploy_pipeline_templates_terraform_validate_build.yml)
- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/config.json](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/config.json)
- [pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/source.yml](pipelines/Devops-Project/Terraform-build-and-deploy/Terraform-build-pipeline/source.yml)
